package ut06e09pasoporvalorpasoporreferencia;

public class CosaClaseInt {
    public int valor;
}

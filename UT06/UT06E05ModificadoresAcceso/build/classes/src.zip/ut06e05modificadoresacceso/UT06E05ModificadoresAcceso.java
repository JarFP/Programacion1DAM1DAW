package ut06e05modificadoresacceso;

import paquete.Ejemplo2;

/**
 *
 */
public class UT06E05ModificadoresAcceso {

    public static void main(String[] args) {
        
        Ejemplo e = new Ejemplo();
        
        // comprueba qué atributos y métodos puedes usar desde aquí
        // mira los iconos que nos muestra NetBeans junto a ellos
        
        // e.
        
        Ejemplo2 e2 = new Ejemplo2();
        
        // comprueba qué atributos y métodos puedes usar desde aquí
        
        // e2.
        
    }
    
    
}
